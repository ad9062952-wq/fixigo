import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Zap, CheckCircle, Clock, Shield, Phone, Wrench, Droplet, Wind, Paintbrush } from 'lucide-react';
import { motion } from 'motion/react';
import Layout from '../components/Layout';
import Tilt from 'react-parallax-tilt';
import { getServices, Service } from '../lib/services';

const Home = () => {
  const [services, setServices] = useState<Service[]>([]);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const data = await getServices();
        setServices(data.slice(0, 6)); // Show up to 6 services on home page
      } catch (error) {
        console.error('Error fetching services:', error);
      }
    };
    fetchServices();
  }, []);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-slate-900 via-blue-900 to-blue-800 text-white overflow-hidden animate-gradient-x">
        <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&auto=format&fit=crop&w=2069&q=80')] bg-cover bg-center mix-blend-overlay pointer-events-none"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32 flex flex-col items-center text-center z-10">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-4xl md:text-6xl font-extrabold tracking-tight mb-6"
          >
            Book Trusted <span className="text-amber-400">Electricians</span> & <br className="hidden md:block" />Home Services Instantly
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="text-xl md:text-2xl text-blue-100 max-w-3xl mb-10"
          >
            Expert professionals for all your home and commercial needs. Safe, affordable, and on-time service guaranteed.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 relative z-20"
          >
            <Link
              to="/book-service"
              className="inline-flex justify-center items-center bg-blue-600 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-blue-700 transition-all transform hover:scale-105 shadow-[0_0_15px_rgba(37,99,235,0.5)]"
            >
              Book Now
            </Link>
            <Link
              to="/services"
              className="inline-flex justify-center items-center bg-white/10 backdrop-blur-sm border border-white/30 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white/20 transition-all transform hover:scale-105 shadow-lg"
            >
              Explore Services
            </Link>
          </motion.div>
        </div>
        
        {/* Animated Background Shapes */}
        <motion.div 
          animate={{ y: [0, -20, 0], rotate: [0, 5, 0] }} 
          transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
          className="absolute top-20 left-10 w-32 h-32 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-30 pointer-events-none"
        />
        <motion.div 
          animate={{ y: [0, 30, 0], rotate: [0, -5, 0] }} 
          transition={{ repeat: Infinity, duration: 7, ease: "easeInOut" }}
          className="absolute bottom-20 right-10 w-48 h-48 bg-indigo-500 rounded-full mix-blend-multiply filter blur-3xl opacity-30 pointer-events-none"
        />
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <motion.div whileHover={{ y: -10 }} className="p-6 bg-slate-50 rounded-2xl hover:shadow-xl transition-all duration-300 border border-slate-100">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-inner">
                <Clock className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">On-Time Service</h3>
              <p className="text-slate-600">We value your time. Our professionals arrive promptly at the scheduled slot.</p>
            </motion.div>
            <motion.div whileHover={{ y: -10 }} className="p-6 bg-slate-50 rounded-2xl hover:shadow-xl transition-all duration-300 border border-slate-100">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-inner">
                <Shield className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Safe & Secure</h3>
              <p className="text-slate-600">Certified professionals following strict safety protocols for your peace of mind.</p>
            </motion.div>
            <motion.div whileHover={{ y: -10 }} className="p-6 bg-slate-50 rounded-2xl hover:shadow-xl transition-all duration-300 border border-slate-100">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-inner">
                <Zap className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Expert Repairs</h3>
              <p className="text-slate-600">From minor fixes to major installations, we handle it all with expertise.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Popular Categories */}
      <section className="py-16 bg-slate-50 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900">Popular Categories</h2>
            <p className="mt-4 text-lg text-slate-600">Find the right professional for your needs</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { name: 'Electrician', icon: Zap, color: 'text-amber-500', bg: 'bg-amber-50' },
              { name: 'Plumber', icon: Droplet, color: 'text-blue-500', bg: 'bg-blue-50' },
              { name: 'AC Repair', icon: Wind, color: 'text-teal-500', bg: 'bg-teal-50' },
              { name: 'Painter', icon: Paintbrush, color: 'text-orange-500', bg: 'bg-orange-50' },
            ].map((cat, index) => (
              <Link to="/services" key={index} className="block h-full">
                <Tilt
                  tiltMaxAngleX={15}
                  tiltMaxAngleY={15}
                  perspective={1000}
                  transitionSpeed={1000}
                  scale={1.05}
                  gyroscope={true}
                  className="bg-white p-6 rounded-2xl shadow-sm hover:shadow-lg transition-all flex flex-col items-center justify-center gap-4 border border-slate-100 cursor-pointer h-full"
                  style={{ transformStyle: "preserve-3d" }}
                >
                  <div className={`${cat.bg} p-4 rounded-full`} style={{ transform: "translateZ(30px)" }}>
                    <cat.icon className={`h-8 w-8 ${cat.color}`} />
                  </div>
                  <span className="font-semibold text-slate-800" style={{ transform: "translateZ(20px)" }}>{cat.name}</span>
                </Tilt>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900">Our Services</h2>
            <p className="text-lg text-slate-600 mt-4">Comprehensive home solutions for every need</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.length > 0 ? services.map((service, index) => (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ type: "spring", stiffness: 300, damping: 20, delay: index * 0.05 }}
                key={service.id} 
              >
                <Tilt
                  tiltMaxAngleX={10}
                  tiltMaxAngleY={10}
                  perspective={1000}
                  transitionSpeed={1000}
                  scale={1.05}
                  gyroscope={true}
                  className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-100 flex items-center space-x-4 h-full"
                  style={{ transformStyle: "preserve-3d" }}
                >
                  <div style={{ transform: "translateZ(30px)" }} className="flex items-center space-x-4 w-full">
                    <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0" />
                    <div>
                      <span className="text-lg font-medium text-slate-800 block">{service.name}</span>
                      <span className="text-xs text-slate-500">{service.category}</span>
                    </div>
                  </div>
                </Tilt>
              </motion.div>
            )) : (
              ['Fan Installation', 'Wiring Repair', 'Switchboard Repair', 'MCB / Fuse Repair', 'Meter Installation', 'Emergency Service'].map((service, index) => (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ type: "spring", stiffness: 300, damping: 20, delay: index * 0.05 }}
                  key={index} 
                >
                  <Tilt
                    tiltMaxAngleX={10}
                    tiltMaxAngleY={10}
                    perspective={1000}
                    transitionSpeed={1000}
                    scale={1.05}
                    gyroscope={true}
                    className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-100 flex items-center space-x-4 h-full"
                    style={{ transformStyle: "preserve-3d" }}
                  >
                    <div style={{ transform: "translateZ(30px)" }} className="flex items-center space-x-4 w-full">
                      <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0" />
                      <span className="text-lg font-medium text-slate-800">{service}</span>
                    </div>
                  </Tilt>
                </motion.div>
              ))
            )}
          </div>
          <div className="text-center mt-10">
            <Link to="/services" className="text-blue-600 font-semibold hover:text-blue-800 flex items-center justify-center gap-1 transition-colors">
              View All Services &rarr;
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 to-indigo-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 pointer-events-none"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.h2 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Need a Service Urgently?
          </motion.h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">Don't wait for small issues to become big problems. Book our expert professionals today.</p>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="inline-block">
            <Link
              to="/book-service"
              className="bg-white text-blue-600 px-10 py-4 rounded-full font-bold text-lg hover:bg-slate-50 transition-colors shadow-[0_10px_25px_rgba(0,0,0,0.2)]"
            >
              Book an Appointment
            </Link>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default Home;
