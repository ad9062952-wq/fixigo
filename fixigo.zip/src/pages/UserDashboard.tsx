import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import Layout from '../components/Layout';
import { Calendar, Clock, MapPin, Wrench, Loader } from 'lucide-react';

interface Booking {
  id: number;
  service_type: string;
  date: string;
  time: string;
  status: string;
  address: string;
  problem: string;
  created_at: string;
  service_mode: string;
  item_name: string;
  item_status: string;
  pickup_date: string;
  delivery_date: string;
  pickup_charge: number;
  delivery_charge: number;
  total_price: number;
  payment_status?: string;
}

const UserDashboard = () => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPaymentModal, setShowPaymentModal] = useState<number | null>(null);

  const fetchBookings = (showLoading = true) => {
    if (user) {
      if (showLoading) setLoading(true);
      try {
        const data = JSON.parse(localStorage.getItem('user_bookings') || '[]');
        setBookings(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    fetchBookings();
  }, [user]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800';
      case 'Assigned': return 'bg-blue-100 text-blue-800';
      case 'In Progress': return 'bg-purple-100 text-purple-800';
      case 'Completed': return 'bg-green-100 text-green-800';
      case 'Cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleCancelBooking = async (id: number) => {
    if (!window.confirm('Are you sure you want to cancel this booking?')) return;
    try {
      const updatedBookings = bookings.map(b => b.id === id ? { ...b, status: 'Cancelled' } : b);
      setBookings(updatedBookings);
      localStorage.setItem('user_bookings', JSON.stringify(updatedBookings));
    } catch (error) {
      console.error('Error cancelling booking:', error);
    }
  };

  return (
    <Layout>
      <div className="bg-gray-50 min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">My Dashboard</h1>
            <p className="text-gray-600">Welcome back, {user?.name}</p>
          </div>

          {/* Items Under Repair Section */}
          {!loading && bookings.filter(b => b.service_mode === 'pickup' && b.status !== 'Completed' && b.status !== 'Cancelled').length > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Items Under Repair</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {bookings
                  .filter(b => b.service_mode === 'pickup' && b.status !== 'Completed' && b.status !== 'Cancelled')
                  .map(booking => (
                    <div key={`repair-${booking.id}`} className="bg-white rounded-xl shadow-md p-6 border-l-4 border-purple-500">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="font-bold text-lg text-gray-900">{booking.item_name}</h3>
                          <p className="text-sm text-gray-500">{booking.service_type}</p>
                        </div>
                        <span className="px-3 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-800">
                          {booking.item_status || 'Requested'}
                        </span>
                      </div>
                      
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Booking ID:</span>
                          <span className="font-medium">#{booking.id}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Pickup Date:</span>
                          <span className="font-medium">{booking.pickup_date || 'Pending'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Expected Return:</span>
                          <span className="font-medium text-blue-600">{booking.delivery_date || 'To be updated'}</span>
                        </div>
                      </div>
                      
                      {/* Progress Bar */}
                      <div className="mt-4 pt-4 border-t border-gray-100">
                        <div className="w-full bg-gray-200 rounded-full h-2 mb-1">
                          <div 
                            className="bg-purple-600 h-2 rounded-full transition-all duration-500" 
                            style={{ 
                              width: (booking.item_status === 'Ready for Delivery' || booking.item_status === 'Delivered') ? '100%' : 
                                     booking.item_status === 'Under Repair' ? '66%' : 
                                     booking.item_status === 'Picked Up' ? '33%' : '10%' 
                            }}
                          ></div>
                        </div>
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>Requested</span>
                          <span>Repairing</span>
                          <span>Ready</span>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800">Booking History</h2>
            </div>

            {loading ? (
              <div className="p-12 flex justify-center">
                <Loader className="h-8 w-8 text-blue-600 animate-spin" />
              </div>
            ) : bookings.length === 0 ? (
              <div className="p-12 text-center text-gray-500">
                <p>You haven't booked any services yet.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Address</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cost</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {bookings.map((booking) => (
                      <tr key={booking.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <Wrench className="h-5 w-5 text-blue-600" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                {booking.service_type}
                                {booking.service_mode === 'pickup' && <span className="ml-2 px-2 py-0.5 rounded text-xs bg-purple-100 text-purple-800">Pickup</span>}
                              </div>
                              <div className="text-sm text-gray-500">{booking.problem}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900 flex items-center gap-1">
                            <Calendar className="h-4 w-4 text-gray-400" /> {booking.date}
                          </div>
                          <div className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                            <Clock className="h-4 w-4 text-gray-400" /> {booking.time}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900 flex items-start gap-1">
                            <MapPin className="h-4 w-4 text-gray-400 mt-0.5 flex-shrink-0" />
                            <span className="truncate max-w-xs">{booking.address}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(booking.status)}`}>
                            {booking.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {booking.service_mode === 'pickup' ? (
                            <div className="flex flex-col">
                              <span className="text-sm font-medium text-gray-900">{booking.item_name}</span>
                              <span className="text-xs text-blue-600 font-semibold">{booking.item_status || 'Requested'}</span>
                              {booking.delivery_date && <span className="text-xs text-gray-500 mt-1">Expected Return: {booking.delivery_date}</span>}
                            </div>
                          ) : (
                            <span className="text-sm text-gray-400">-</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {booking.total_price ? (
                            <div className="text-sm text-gray-900 font-medium">
                              <p>Total: ₹{booking.total_price}</p>
                              {booking.service_mode === 'pickup' && (booking.pickup_charge > 0 || booking.delivery_charge > 0) && (
                                <div className="text-xs text-gray-500 mt-1">
                                  {booking.pickup_charge > 0 && <p>Pickup: ₹{booking.pickup_charge}</p>}
                                  {booking.delivery_charge > 0 && <p>Delivery: ₹{booking.delivery_charge}</p>}
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="text-sm text-gray-900">
                              <span className="text-gray-400 italic">Pending</span>
                              {booking.service_mode === 'pickup' && (booking.pickup_charge > 0 || booking.delivery_charge > 0) && (
                                <div className="text-xs text-gray-500 mt-1">
                                  {booking.pickup_charge > 0 && <p>Pickup: ₹{booking.pickup_charge}</p>}
                                  {booking.delivery_charge > 0 && <p>Delivery: ₹{booking.delivery_charge}</p>}
                                </div>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          {booking.status === 'Pending' && (
                            <button
                              onClick={() => handleCancelBooking(booking.id)}
                              className="text-red-600 hover:text-red-900"
                            >
                              Cancel
                            </button>
                          )}
                          {booking.status === 'Completed' && booking.payment_status === 'Pending' && (
                            <button
                              onClick={() => setShowPaymentModal(booking.id)}
                              className="bg-green-600 text-white px-3 py-1.5 rounded hover:bg-green-700 transition-colors"
                            >
                              Pay Now
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Payment Modal */}
      {(showPaymentModal || bookings.find(b => b.status === 'Completed' && b.payment_status === 'Pending')) && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-6 text-center relative">
            {showPaymentModal && (
              <button 
                onClick={() => setShowPaymentModal(null)}
                className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            )}
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Payment Required</h2>
            <p className="text-gray-600 mb-6">Please scan the QR code to complete the payment.</p>
            
            <div className="bg-gray-50 p-4 rounded-lg flex justify-center mb-6 border border-gray-200">
              <img src="https://imglink.cc/cdn/TMdkrlioY1.png" alt="Payment QR Code" className="max-w-full h-auto rounded" />
            </div>
            
            <button 
              onClick={async () => {
                const pendingBookingId = showPaymentModal || bookings.find(b => b.status === 'Completed' && b.payment_status === 'Pending')?.id;
                if (pendingBookingId) {
                  try {
                    const updatedBookings = bookings.map(b => b.id === pendingBookingId ? { ...b, payment_status: 'Paid' } : b);
                    setBookings(updatedBookings);
                    localStorage.setItem('user_bookings', JSON.stringify(updatedBookings));
                    setShowPaymentModal(null);
                  } catch (error) {
                    console.error('Error updating payment status:', error);
                  }
                }
              }}
              className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-bold text-lg hover:bg-green-700 transition-colors shadow-md"
            >
              Payment Done
            </button>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default UserDashboard;
