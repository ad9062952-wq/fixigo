import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Layout from '../components/Layout';
import { Shield, Lock, AlertCircle } from 'lucide-react';

const AdminLogin = () => {
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Master password check
      if (mobile === '8010733617' && password === 'mayuri8010') {
        login({
          id: 1,
          name: 'Admin',
          mobile: '8010733617',
          role: 'admin'
        });
        navigate('/admin-dashboard');
        return;
      }

      // Check Supabase first
      const { supabase } = await import('../lib/supabase');
      try {
        const { data: adminUsers, error } = await supabase
          .from('users')
          .select('*')
          .eq('mobile', mobile)
          .eq('role', 'admin')
          .limit(1);

        if (!error && adminUsers && adminUsers.length > 0) {
          if (adminUsers[0].password_hash === password) {
            login({
              id: adminUsers[0].id,
              name: adminUsers[0].name || 'Admin',
              mobile: mobile,
              role: 'admin'
            });
            navigate('/admin-dashboard');
            return;
          }
        }
      } catch (dbErr) {
        console.log("Supabase login check failed, falling back to local:", dbErr);
      }

      // Hardcoded admin credentials for local version fallback
      const storedAdminPass = localStorage.getItem('admin_password');
      const storedAdminMobile = localStorage.getItem('admin_mobile') || '8010733617';
      
      if (storedAdminPass && mobile === storedAdminMobile && password === storedAdminPass) {
        login({
          id: 1,
          name: 'Admin',
          mobile: storedAdminMobile,
          role: 'admin'
        });
        navigate('/admin-dashboard');
      } else {
        setError('Invalid credentials. Use 8010733617 / mayuri8010');
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="min-h-[calc(100vh-200px)] flex items-center justify-center bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8 bg-white p-10 rounded-2xl shadow-lg border border-slate-100">
          <div className="flex flex-col items-center">
            <div className="bg-blue-50 p-4 rounded-full mb-4 shadow-inner">
              <Shield className="h-8 w-8 text-blue-600" />
            </div>
            <h2 className="text-center text-3xl font-extrabold text-slate-900">Admin Portal</h2>
            <p className="mt-2 text-center text-sm text-slate-600">
              Sign in to manage the platform
            </p>
          </div>
          <form className="mt-8 space-y-6" onSubmit={handleSubmit} autoComplete="off">
            {error && (
              <div className="bg-red-50 border-l-4 border-red-500 p-4 flex items-center rounded-r-md">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            )}
            <div className="rounded-md shadow-sm -space-y-px">
              <div className="relative">
                <Shield className="absolute top-3 left-3 h-5 w-5 text-slate-400" />
                <input
                  id="mobile"
                  name="mobile"
                  type="text"
                  required
                  autoComplete="off"
                  className="appearance-none rounded-none relative block w-full px-10 py-3 border border-slate-300 placeholder-slate-500 text-slate-900 rounded-t-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm transition-colors"
                  placeholder="Admin Username (Mobile)"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                />
              </div>
              <div className="relative">
                <Lock className="absolute top-3 left-3 h-5 w-5 text-slate-400" />
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  autoComplete="new-password"
                  className="appearance-none rounded-none relative block w-full px-10 py-3 border border-slate-300 placeholder-slate-500 text-slate-900 rounded-b-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm transition-colors"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            <div>
              <button
                type="submit"
                disabled={loading}
                className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-slate-900 hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-900 transition-all hover:scale-[1.02] shadow-md hover:shadow-lg disabled:opacity-50 disabled:hover:scale-100"
              >
                {loading ? 'Authenticating...' : 'Secure Login'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </Layout>
  );
};

export default AdminLogin;
