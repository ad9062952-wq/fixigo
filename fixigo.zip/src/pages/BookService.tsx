import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Layout from '../components/Layout';
import { Calendar, Clock, MapPin, Wrench, AlertCircle, CheckCircle, FileText, Image } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import L from 'leaflet';
import { motion } from 'motion/react';
import { getServices, Service } from '../lib/services';

// Fix for default marker icons in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const providerIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const BookService = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [services, setServices] = useState<Service[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [formData, setFormData] = useState({
    name: user?.name || '',
    mobile: user?.mobile || '',
    address: '',
    serviceId: '',
    problem: '',
    date: '',
    time: '',
    photo: '',
    serviceMode: 'home',
    itemName: '',
    latitude: null as number | null,
    longitude: null as number | null
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [nearbyProviders, setNearbyProviders] = useState<any[]>([]);

  const [fetchingLocation, setFetchingLocation] = useState(false);

  useEffect(() => {
    // Fetch services
    const fetchServices = async () => {
      try {
        const data = await getServices();
        setServices(data);
        if (data.length > 0) {
          const firstCategory = data[0].category || 'Electrician';
          setSelectedCategory(firstCategory);
          const firstService = data.find((s: any) => (s.category || 'Electrician') === firstCategory);
          if (firstService) {
            setFormData(prev => ({ ...prev, serviceId: firstService.id.toString() }));
          }
        }
      } catch (err) {
        console.error("Failed to fetch services", err);
      }
    };
    fetchServices();

    // Auto-fetch location on mount
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData(prev => ({
            ...prev,
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          }));
        },
        (err) => {
          console.warn('Auto-location failed:', err.message);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    }
  }, []);

  const getLocation = () => {
    setFetchingLocation(true);
    setError('');
    if (navigator.geolocation) {
      // Ask for permission explicitly
      navigator.permissions?.query({ name: 'geolocation' }).then(function(result) {
        if (result.state === 'denied') {
          setError('Failed to get location. Please enable location services in your browser settings.');
          setFetchingLocation(false);
        }
      });

      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData(prev => ({
            ...prev,
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          }));
          setFetchingLocation(false);
        },
        (err) => {
          setError('Failed to get location. Please enable location services.');
          setFetchingLocation(false);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      setError('Geolocation is not supported by this browser.');
      setFetchingLocation(false);
    }
  };

  // Live tracking effect removed since backend is removed

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newCategory = e.target.value;
    setSelectedCategory(newCategory);
    const firstService = services.find(s => (s.category || 'Electrician') === newCategory);
    if (firstService) {
      setFormData(prev => ({ ...prev, serviceId: firstService.id.toString() }));
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('Photo size should be less than 5MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, photo: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.mobile) {
      setError('Please provide your name and mobile number.');
      return;
    }

    setLoading(true);
    setError('');

    // Try to get location if not already captured
    let currentLat = formData.latitude;
    let currentLng = formData.longitude;

    if (!currentLat || !currentLng) {
      if (navigator.geolocation) {
        try {
          const position = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 10000, enableHighAccuracy: true });
          });
          currentLat = position.coords.latitude;
          currentLng = position.coords.longitude;
          setFormData(prev => ({ ...prev, latitude: currentLat, longitude: currentLng }));
        } catch (err) {
          console.log("Could not fetch location on submit:", err);
        }
      }
    }

    try {
      // Find the selected service name
      const selectedService = services.find(s => s.id.toString() === formData.serviceId);
      const serviceName = selectedService ? selectedService.name : 'Service';
      
      // Construct WhatsApp message with Live Location
      let locationText = '';
      let mapsLink = '';
      if (currentLat && currentLng) {
        mapsLink = `https://www.google.com/maps?q=${currentLat},${currentLng}`;
        locationText = `\n*Live Location:* ${mapsLink}`;
      }

      const message = `*New Service Booking!*\n\n*Name:* ${formData.name}\n*Mobile:* ${formData.mobile}\n*Category:* ${selectedCategory}\n*Service:* ${serviceName}\n*Mode:* ${formData.serviceMode === 'pickup' ? 'Pickup & Repair' : 'Home Repair'}\n*Address:* ${formData.address}${locationText}\n*Problem:* ${formData.problem}\n*Date:* ${formData.date}\n*Time:* ${formData.time}\n\n*Note:* ₹12 per km travel charges will apply.`;
      
      const encodedMessage = encodeURIComponent(message);
      
      // Open WhatsApp in a new tab
      window.open(`https://wa.me/917821835922?text=${encodedMessage}`, '_blank');

      // Save booking to Supabase
      const { supabase } = await import('../lib/supabase');
      
      try {
        // 1. Find or create user
        let userId = null;
        
        // First check if user exists
        const { data: existingUsers, error: userFetchError } = await supabase
          .from('users')
          .select('id')
          .eq('mobile', formData.mobile)
          .limit(1);
          
        if (userFetchError) throw userFetchError;
        
        if (existingUsers && existingUsers.length > 0) {
          userId = existingUsers[0].id;
        } else {
          // Create new user
          const { data: newUser, error: userCreateError } = await supabase
            .from('users')
            .insert([{ 
              name: formData.name, 
              mobile: formData.mobile, 
              role: 'customer',
              password_hash: 'default_hash_for_unregistered'
            }])
            .select();
            
          if (userCreateError) throw userCreateError;
          if (newUser && newUser.length > 0) {
            userId = newUser[0].id;
            
            // Also add to customers table
            await supabase.from('customers').insert([{
              user_id: userId,
              address: formData.address
            }]);
          }
        }
        
        // 2. Create booking
        if (userId) {
          const newBooking = {
            customer_id: userId,
            service_id: parseInt(formData.serviceId),
            address: formData.address,
            problem_description: formData.problem,
            booking_date: formData.date,
            booking_time: formData.time,
            status: 'Pending',
            service_mode: formData.serviceMode,
            item_name: formData.itemName,
            item_status: 'pending_pickup',
            latitude: currentLat,
            longitude: currentLng
          };
          
          await supabase.from('bookings').insert([newBooking]);
        }
      } catch (dbErr) {
        console.error("Failed to save to Supabase:", dbErr);
      }

      // Save booking to local storage for User Dashboard as fallback
      const localBooking = {
        id: Date.now(),
        service_type: `${selectedCategory} - ${serviceName}`,
        date: formData.date,
        time: formData.time,
        status: 'Pending',
        address: formData.address,
        problem: formData.problem,
        created_at: new Date().toISOString(),
        service_mode: formData.serviceMode,
        item_name: formData.itemName,
        item_status: 'pending_pickup',
        pickup_date: '',
        delivery_date: '',
        pickup_charge: 0,
        delivery_charge: 0,
        total_price: 0
      };
      
      const existingBookings = JSON.parse(localStorage.getItem('user_bookings') || '[]');
      localStorage.setItem('user_bookings', JSON.stringify([localBooking, ...existingBookings]));

      setSuccess(true);
      setTimeout(() => navigate('/'), 3000);
    } catch (err) {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <Layout>
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, type: "spring" }}
          className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          >
            <CheckCircle className="h-20 w-20 text-green-500 mb-6" />
          </motion.div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Booking Confirmed!</h2>
          <p className="text-gray-600 text-lg">Your service request has been submitted successfully.</p>
          <p className="text-gray-500 mt-2">Opening WhatsApp to send details to admin...</p>
          <p className="text-gray-500 mt-1">Redirecting to home...</p>
        </motion.div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="bg-slate-50 py-12 min-h-screen">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100"
          >
            <div className="bg-gradient-to-r from-slate-900 to-blue-800 py-6 px-8">
              <h1 className="text-2xl font-bold text-white">Book a Service</h1>
              <p className="text-blue-100 mt-1">Fill in the details below to schedule an appointment.</p>
            </div>
            
            <form onSubmit={handleSubmit} className="p-8 space-y-6">
              {error && (
                <div className="bg-red-50 border-l-4 border-red-500 p-4 flex items-center">
                  <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                  <p className="text-red-700">{error}</p>
                </div>
              )}

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-start">
                <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5 mr-3 flex-shrink-0" />
                <div>
                  <h4 className="text-sm font-semibold text-yellow-800">Important Note</h4>
                  <p className="text-sm text-yellow-700 mt-1">₹12 per km travel charges will apply for all services.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Mobile Number</label>
                  <input
                    type="tel"
                    name="mobile"
                    required
                    value={formData.mobile}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Service Category</label>
                  <div className="relative">
                    <Wrench className="absolute top-3 left-3 h-5 w-5 text-gray-400" />
                    <select
                      value={selectedCategory}
                      onChange={handleCategoryChange}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 appearance-none bg-white transition-colors"
                    >
                      {Array.from(new Set(services.map(s => s.category || 'Electrician'))).map(cat => (
                        <option key={cat as string} value={cat as string}>{cat as string}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Specific Service</label>
                  <div className="relative">
                    <Wrench className="absolute top-3 left-3 h-5 w-5 text-gray-400" />
                    <select
                      name="serviceId"
                      required
                      value={formData.serviceId}
                      onChange={handleChange}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 appearance-none bg-white transition-colors"
                    >
                      {services.filter(s => (s.category || 'Electrician') === selectedCategory).map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.price_range})</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
                <div className="relative">
                  <MapPin className="absolute top-3 left-3 h-5 w-5 text-gray-400" />
                  <textarea
                    name="address"
                    required
                    rows={3}
                    value={formData.address}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
                    placeholder="Enter your full address with landmark"
                  />
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={getLocation}
                    disabled={fetchingLocation}
                    className="text-sm text-blue-600 hover:text-blue-800 flex items-center font-medium transition-colors disabled:opacity-50"
                  >
                    <MapPin className="h-4 w-4 mr-1" /> {fetchingLocation ? 'Fetching...' : 'Get Current Location'}
                  </button>
                  {formData.latitude && (
                    <span className="text-xs text-green-600 font-medium">Location captured</span>
                  )}
                </div>
                
                {formData.latitude && formData.longitude && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-md border border-blue-100 shadow-sm">
                    <h4 className="text-sm font-semibold text-blue-900 mb-2">
                      {nearbyProviders.length > 0 ? `Live Tracking: Nearby Providers (${nearbyProviders.length})` : 'Your Location'}
                    </h4>
                    <div className="h-64 w-full rounded-md overflow-hidden border border-gray-300 mb-4 z-0 relative">
                      <MapContainer 
                        center={[formData.latitude, formData.longitude]} 
                        zoom={13} 
                        style={{ height: '100%', width: '100%' }}
                      >
                        <TileLayer
                          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        />
                        {/* User Location */}
                        <Marker position={[formData.latitude, formData.longitude]}>
                          <Popup>Your Location</Popup>
                        </Marker>
                        <Circle 
                          center={[formData.latitude, formData.longitude]} 
                          radius={10000} // 10km radius
                          pathOptions={{ color: 'blue', fillColor: 'blue', fillOpacity: 0.1 }} 
                        />
                        
                        {/* Provider Locations */}
                        {nearbyProviders.map((provider) => (
                          <Marker 
                            key={provider.id} 
                            position={[provider.latitude, provider.longitude]}
                            icon={providerIcon}
                          >
                            <Popup>
                              <strong>{provider.name}</strong><br/>
                              {provider.distance.toFixed(1)} km away
                            </Popup>
                          </Marker>
                        ))}
                      </MapContainer>
                    </div>
                    <ul className="space-y-2">
                      {nearbyProviders.map((provider) => (
                        <li key={provider.id} className="text-sm flex justify-between items-center bg-white p-2 rounded border border-blue-50">
                          <span>{provider.name}</span>
                          <span className="text-gray-500">{provider.distance.toFixed(1)} km away</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Service Mode</label>
                  <div className="flex space-x-4 mt-2">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="serviceMode"
                        value="home"
                        checked={formData.serviceMode === 'home'}
                        onChange={handleChange}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                      />
                      <span className="ml-2 text-slate-700">Home Repair</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="serviceMode"
                        value="pickup"
                        checked={formData.serviceMode === 'pickup'}
                        onChange={handleChange}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                      />
                      <span className="ml-2 text-slate-700">Pickup & Repair</span>
                    </label>
                  </div>
                </div>
                {formData.serviceMode === 'pickup' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Item Name (to be picked up)</label>
                    <input
                      type="text"
                      name="itemName"
                      required={formData.serviceMode === 'pickup'}
                      value={formData.itemName}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
                      placeholder="e.g., Ceiling Fan, Mixer Grinder"
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Problem Description</label>
                <div className="relative">
                  <FileText className="absolute top-3 left-3 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    name="problem"
                    required
                    value={formData.problem}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
                    placeholder="Briefly describe the issue"
                  />
                </div>
              </div>

              {selectedCategory !== 'Painter' && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Problem Photo (Optional)</label>
                  <div className="relative">
                    <Image className="absolute top-3 left-3 h-5 w-5 text-gray-400" />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        handlePhotoUpload(e);
                        if (e.target.files && e.target.files.length > 0) {
                          alert("Please remember to attach this photo in WhatsApp after it opens!");
                        }
                      }}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Note: You will need to manually attach this photo in WhatsApp after clicking submit.</p>
                  {formData.photo && (
                    <div className="mt-2">
                      <img src={formData.photo} alt="Preview" className="h-20 w-20 object-cover rounded-md border border-gray-200" />
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Preferred Date</label>
                  <div className="relative">
                    <Calendar className="absolute top-3 left-3 h-5 w-5 text-gray-400" />
                    <input
                      type="date"
                      name="date"
                      required
                      min={new Date().toISOString().split('T')[0]}
                      value={formData.date}
                      onChange={handleChange}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Preferred Time</label>
                  <div className="relative">
                    <Clock className="absolute top-3 left-3 h-5 w-5 text-gray-400" />
                    <select
                      name="time"
                      required
                      value={formData.time}
                      onChange={handleChange}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 appearance-none bg-white transition-colors"
                    >
                      <option value="">Select a time slot</option>
                      <option value="09:00 AM - 11:00 AM">09:00 AM - 11:00 AM</option>
                      <option value="11:00 AM - 01:00 PM">11:00 AM - 01:00 PM</option>
                      <option value="02:00 PM - 04:00 PM">02:00 PM - 04:00 PM</option>
                      <option value="04:00 PM - 06:00 PM">04:00 PM - 06:00 PM</option>
                      <option value="06:00 PM - 08:00 PM">06:00 PM - 08:00 PM</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6 flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-semibold text-green-800">No Payment Required Now</h4>
                    <p className="text-sm text-green-700 mt-1">You don't need to pay anything to book. Your booking details and live location will be sent directly via WhatsApp.</p>
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all hover:scale-[1.02] shadow-md hover:shadow-lg disabled:opacity-50 disabled:hover:scale-100"
                >
                  {loading ? 'Processing...' : 'Confirm Booking & Send WhatsApp'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
};

export default BookService;
