import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import Layout from '../components/Layout';
import { Calendar, Clock, MapPin, Wrench, CheckCircle, DollarSign, Loader, User, QrCode } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

interface Job {
  id: number;
  name: string; // Customer name
  mobile: string;
  address: string;
  service_type: string;
  problem: string;
  date: string;
  time: string;
  status: string;
  total_price: number;
  electrician_earning: number;
  service_mode: string;
  item_name: string;
  item_status: string;
  pickup_date: string;
  delivery_date: string;
  pickup_charge: number;
  delivery_charge: number;
  payment_status?: string;
}

interface Stats {
  total_jobs: number;
  total_earnings: number;
}

const ElectricianDashboard = () => {
  const { user } = useAuth();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [stats, setStats] = useState<Stats>({ total_jobs: 0, total_earnings: 0 });
  const [loading, setLoading] = useState(true);
  const [completingJob, setCompletingJob] = useState<number | null>(null);
  const [updatingStatus, setUpdatingStatus] = useState<number | null>(null);
  const [completionData, setCompletionData] = useState({ totalPrice: '', paymentCollectedBy: 'Electrician' });
  const [showPaymentModal, setShowPaymentModal] = useState<number | null>(null);

  const fetchDashboard = async (showLoading = true) => {
    if (!user) return;
    if (showLoading) setLoading(true);
    try {
      const data = JSON.parse(localStorage.getItem('user_bookings') || '[]');
      setJobs(data);
      setStats({ total_jobs: data.length, total_earnings: 0 });
    } catch (error) {
      console.error(error);
    } finally {
      if (showLoading) setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, [user]);

  const handleUpdateStatus = async (jobId: number, status: string) => {
    try {
      const updatedJobs = jobs.map(j => j.id === jobId ? { ...j, status } : j);
      setJobs(updatedJobs);
      localStorage.setItem('user_bookings', JSON.stringify(updatedJobs));
      setUpdatingStatus(null);
    } catch (error) {
      console.error('Error updating job status:', error);
    }
  };

  const handleUpdateItemStatus = async (jobId: number, itemStatus: string) => {
    try {
      const updatedJobs = jobs.map(j => j.id === jobId ? { ...j, item_status: itemStatus } : j);
      setJobs(updatedJobs);
      localStorage.setItem('user_bookings', JSON.stringify(updatedJobs));
    } catch (error) {
      console.error('Error updating item status:', error);
    }
  };

  const handleCompleteJob = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!completingJob) return;

    try {
      const updatedJobs = jobs.map(j => j.id === completingJob ? { 
        ...j, 
        status: 'Completed', 
        total_price: Number(completionData.totalPrice),
        payment_status: 'Pending'
      } : j);
      setJobs(updatedJobs);
      localStorage.setItem('user_bookings', JSON.stringify(updatedJobs));
      
      const jobId = completingJob;
      setCompletingJob(null);
      setCompletionData({ totalPrice: '', paymentCollectedBy: 'Electrician' });
      setShowPaymentModal(jobId);
    } catch (error) {
      console.error('Error completing job:', error);
    }
  };

  const handlePaymentDone = async () => {
    if (!showPaymentModal) return;
    try {
      const updatedJobs = jobs.map(j => j.id === showPaymentModal ? { ...j, payment_status: 'Paid' } : j);
      setJobs(updatedJobs);
      localStorage.setItem('user_bookings', JSON.stringify(updatedJobs));
      setShowPaymentModal(null);
    } catch (error) {
      console.error('Error updating payment status:', error);
    }
  };

  return (
    <Layout>
      <div className="bg-slate-50 min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8 flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Provider Dashboard</h1>
              <p className="text-slate-600">Welcome, {user?.name}</p>
            </div>
            <div className="bg-white px-6 py-3 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-4 hover:shadow-md transition-shadow">
              <div>
                <p className="text-sm text-slate-500">Total Earnings</p>
                <p className="text-2xl font-bold text-green-600">₹{stats.total_earnings || 0}</p>
              </div>
              <div className="bg-green-50 p-3 rounded-full shadow-inner">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center py-12">
              <Loader className="h-8 w-8 text-blue-600 animate-spin" />
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Active Jobs */}
              <div className="space-y-6">
                <h2 className="text-xl font-bold text-slate-800">Assigned Jobs</h2>
                {jobs.filter(j => j.status === 'Assigned' || j.status === 'In Progress').length === 0 ? (
                  <p className="text-slate-500 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">No active jobs assigned.</p>
                ) : (
                  jobs.filter(j => j.status === 'Assigned' || j.status === 'In Progress').map(job => (
                    <div key={job.id} className="bg-white rounded-2xl shadow-sm p-6 border-l-4 border-blue-500 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-bold text-slate-900">{job.service_type}</h3>
                          <p className="text-sm text-slate-500">#{job.id}</p>
                        </div>
                        <span className="bg-blue-50 text-blue-700 text-xs px-3 py-1 rounded-full font-semibold border border-blue-100">
                          {job.status}
                        </span>
                      </div>
                      
                      <div className="space-y-3 mb-6">
                        <div className="flex items-start gap-3">
                          <User className="h-5 w-5 text-slate-400 mt-0.5" />
                          <div>
                            <p className="font-medium text-slate-900">{job.name}</p>
                            <p className="text-sm text-slate-500">{job.mobile}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <MapPin className="h-5 w-5 text-slate-400 mt-0.5" />
                          <p className="text-slate-700">{job.address}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <Calendar className="h-5 w-5 text-slate-400" />
                          <p className="text-slate-700">{job.date} at {job.time}</p>
                        </div>
                        <div className="flex items-start gap-3">
                          <Wrench className="h-5 w-5 text-slate-400 mt-0.5" />
                          <p className="text-slate-700">{job.problem}</p>
                        </div>
                        {job.service_mode === 'pickup' && (
                          <div className="bg-purple-50 p-4 rounded-xl border border-purple-100 mt-4">
                            <p className="text-sm font-semibold text-purple-800 mb-2">Pickup & Repair Service</p>
                            <p className="text-sm text-slate-700"><span className="font-medium">Item:</span> {job.item_name}</p>
                            <p className="text-sm text-slate-700"><span className="font-medium">Status:</span> {job.item_status || 'Requested'}</p>
                            
                            {job.status === 'In Progress' && (
                              <div className="mt-4 flex flex-wrap gap-2">
                                {(!job.item_status || job.item_status === 'Requested') && (
                                  <button onClick={() => handleUpdateItemStatus(job.id, 'Picked Up')} className="text-xs bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors shadow-sm">Mark Picked Up</button>
                                )}
                                {job.item_status === 'Picked Up' && (
                                  <button onClick={() => handleUpdateItemStatus(job.id, 'Under Repair')} className="text-xs bg-amber-500 text-white px-4 py-2 rounded-lg hover:bg-amber-600 transition-colors shadow-sm">Mark Under Repair</button>
                                )}
                                {job.item_status === 'Under Repair' && (
                                  <button onClick={() => handleUpdateItemStatus(job.id, 'Ready')} className="text-xs bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors shadow-sm">Mark Ready</button>
                                )}
                                {job.item_status === 'Ready' && (
                                  <button onClick={() => handleUpdateItemStatus(job.id, 'Delivered')} className="text-xs bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors shadow-sm">Mark Delivered</button>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      {completingJob === job.id ? (
                        <form onSubmit={handleCompleteJob} className="bg-slate-50 p-5 rounded-xl space-y-4 border border-slate-100">
                          {job.service_mode === 'pickup' && (job.pickup_charge > 0 || job.delivery_charge > 0) && (
                            <div className="bg-blue-50 p-4 rounded-lg text-sm text-blue-800 border border-blue-100">
                              <p className="font-semibold mb-2">Additional Charges Applied:</p>
                              {job.pickup_charge > 0 && <p className="mb-1">Pickup: ₹{job.pickup_charge}</p>}
                              {job.delivery_charge > 0 && <p className="mb-1">Delivery: ₹{job.delivery_charge}</p>}
                              <p className="mt-2 text-xs opacity-80">Please include these in the total service price.</p>
                            </div>
                          )}
                          <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Total Service Price (₹)</label>
                            <input
                              type="number"
                              required
                              className="w-full rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2.5 border transition-colors"
                              value={completionData.totalPrice}
                              onChange={(e) => setCompletionData({...completionData, totalPrice: e.target.value})}
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Payment Collected By</label>
                            <select
                              className="w-full rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2.5 border transition-colors"
                              value={completionData.paymentCollectedBy}
                              onChange={(e) => setCompletionData({...completionData, paymentCollectedBy: e.target.value})}
                            >
                              <option value="Electrician">Me (Cash/UPI)</option>
                              <option value="Platform">Platform (Online)</option>
                            </select>
                          </div>
                          
                          {completionData.paymentCollectedBy === 'Electrician' && completionData.totalPrice && Number(completionData.totalPrice) > 0 && (
                            <div className="mt-4 p-5 bg-white border border-slate-200 rounded-xl flex flex-col items-center justify-center shadow-sm">
                              <p className="text-sm font-medium text-slate-700 mb-3 flex items-center">
                                <QrCode className="h-5 w-5 mr-2" /> Scan to Pay via UPI
                              </p>
                              <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-100">
                                <QRCodeSVG 
                                  value={`upi://pay?pa=merchant@upi&pn=Fixigo&am=${completionData.totalPrice}&cu=INR`} 
                                  size={160} 
                                />
                              </div>
                              <p className="text-sm font-semibold text-slate-600 mt-3">Amount: ₹{completionData.totalPrice}</p>
                            </div>
                          )}

                          <div className="flex gap-3 pt-2">
                            <button type="submit" className="flex-1 bg-green-600 text-white px-4 py-2.5 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors shadow-sm">
                              Submit & Complete
                            </button>
                            <button 
                              type="button" 
                              onClick={() => {
                                setCompletingJob(null);
                                setCompletionData({ totalPrice: '', paymentCollectedBy: 'Electrician' });
                              }}
                              className="flex-1 bg-slate-200 text-slate-700 px-4 py-2.5 rounded-lg text-sm font-medium hover:bg-slate-300 transition-colors"
                            >
                              Cancel
                            </button>
                          </div>
                        </form>
                      ) : (
                        <div className="flex gap-3">
                          {job.status === 'Assigned' && (
                            <button
                              onClick={() => handleUpdateStatus(job.id, 'In Progress')}
                              className="flex-1 bg-blue-600 text-white py-2.5 rounded-lg font-medium hover:bg-blue-700 transition-colors text-sm shadow-sm"
                            >
                              Start Job
                            </button>
                          )}
                          <button
                            onClick={() => {
                              setCompletingJob(job.id);
                              const baseCharge = (job.pickup_charge || 0) + (job.delivery_charge || 0);
                              setCompletionData({ ...completionData, totalPrice: baseCharge > 0 ? baseCharge.toString() : '' });
                            }}
                            className="flex-1 bg-green-600 text-white py-2.5 rounded-lg font-medium hover:bg-green-700 transition-colors text-sm shadow-sm"
                          >
                            Mark Completed
                          </button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* Job History */}
              <div className="space-y-6">
                <h2 className="text-xl font-bold text-slate-800">Completed Jobs</h2>
                {jobs.filter(j => j.status === 'Completed').length === 0 ? (
                  <p className="text-slate-500 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">No completed jobs yet.</p>
                ) : (
                  jobs.filter(j => j.status === 'Completed').map(job => (
                    <div key={job.id} className="bg-white rounded-2xl shadow-sm p-6 border border-slate-100 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start mb-3">
                        <h3 className="font-bold text-slate-900">{job.service_type}</h3>
                        <span className="bg-green-50 text-green-700 text-xs px-3 py-1 rounded-full font-semibold border border-green-100">
                          Completed
                        </span>
                      </div>
                      <p className="text-sm text-slate-500 mb-3">{job.date}</p>
                      <div className="border-t border-slate-100 pt-3 mt-3 flex justify-between items-center">
                        <span className="text-sm text-slate-600">Total: ₹{job.total_price}</span>
                        <span className="font-bold text-green-600">Your Share: ₹{job.electrician_earning}</span>
                      </div>
                      {job.payment_status === 'Pending' && (
                        <div className="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center">
                          <span className="text-sm font-medium text-amber-600 flex items-center">
                            <Clock className="h-4 w-4 mr-1.5" /> Payment Pending
                          </span>
                          <button 
                            onClick={() => setShowPaymentModal(job.id)}
                            className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors shadow-sm"
                          >
                            Collect Payment
                          </button>
                        </div>
                      )}
                      {job.payment_status === 'Paid' && (
                        <div className="mt-4 pt-4 border-t border-slate-100">
                          <span className="text-sm font-medium text-green-600 flex items-center">
                            <CheckCircle className="h-4 w-4 mr-1.5" /> Payment Received
                          </span>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-8 text-center border border-slate-100">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Payment Required</h2>
            <p className="text-slate-600 mb-6">Please scan the QR code to complete the payment.</p>
            
            <div className="bg-slate-50 p-6 rounded-xl flex justify-center mb-6 border border-slate-200">
              <img src="https://imglink.cc/cdn/TMdkrlioY1.png" alt="Payment QR Code" className="max-w-full h-auto rounded-lg shadow-sm" />
            </div>
            
            <button 
              onClick={handlePaymentDone}
              className="w-full bg-green-600 text-white py-3.5 px-4 rounded-xl font-bold text-lg hover:bg-green-700 transition-colors shadow-md"
            >
              Payment Done
            </button>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default ElectricianDashboard;
