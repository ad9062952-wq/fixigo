import React from 'react';
import Layout from '../components/Layout';
import { CheckCircle } from 'lucide-react';

const About = () => {
  return (
    <Layout>
      <div className="bg-white py-16 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
            <div className="mb-10 lg:mb-0">
              <img
                src="https://images.unsplash.com/photo-1621905252507-b35492cc74b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=2069&q=80"
                alt="Electrician at work"
                className="rounded-2xl shadow-xl w-full object-cover h-[500px]"
              />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-slate-900 mb-6">About Fixigo Services</h1>
              <p className="text-lg text-slate-600 mb-6">
                Established in 2026 by Ritesh Rokade and Abhay Deshmukh, Fixigo Services has been a trusted name in residential and commercial home solutions. We pride ourselves on delivering high-quality workmanship with a focus on safety and customer satisfaction.
              </p>
              <p className="text-lg text-slate-600 mb-4">
                Our team consists of certified and experienced professionals who are equipped to handle any home service challenge, from simple repairs to complex installations.
              </p>
              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-8 rounded-r-md">
                <p className="text-blue-800 font-medium">
                  Note: A travel charge of ₹12 per km applies to all services.
                </p>
              </div>

              <div className="space-y-4">
                {[
                  'Certified & Experienced Professionals',
                  'Transparent Pricing',
                  '100% Satisfaction Guarantee',
                  '24/7 Emergency Support',
                  'High-Quality Safety Standards'
                ].map((item, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0" />
                    <span className="text-slate-800 font-medium">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default About;
