import React from 'react';
import Layout from '../components/Layout';
import { MapPin, Phone, Mail, Clock, MessageCircle } from 'lucide-react';

const Contact = () => {
  return (
    <Layout>
      <div className="bg-slate-50 py-16 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold text-slate-900 mb-4">Contact Us</h1>
            <p className="text-lg text-slate-600">Get in touch with us for any queries or support.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-8 hover:shadow-md transition-shadow">
              <h2 className="text-2xl font-bold text-slate-900 mb-8">Get In Touch</h2>
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-50 p-3 rounded-full shadow-inner">
                    <MapPin className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">Our Location</h3>
                    <p className="text-slate-600 mt-1">Pune, Maharashtra, India</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-green-50 p-3 rounded-full shadow-inner">
                    <MessageCircle className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">WhatsApp</h3>
                    <a href="https://wa.me/917821835922" target="_blank" rel="noopener noreferrer" className="text-slate-600 mt-1 hover:text-green-600 transition-colors block">+91 78218 35922</a>
                    <p className="text-sm text-slate-500">Fastest way to reach us</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-50 p-3 rounded-full shadow-inner">
                    <Phone className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">Phone Number</h3>
                    <a href="tel:+917821835922" className="text-slate-600 mt-1 hover:text-blue-600 transition-colors block">+91 78218 35922</a>
                    <p className="text-sm text-slate-500">Mon-Sat 9am to 6pm</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-50 p-3 rounded-full shadow-inner">
                    <Mail className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">Email Address</h3>
                    <a href="mailto:fixigoservices247@gmail.com" className="text-slate-600 mt-1 hover:text-blue-600 transition-colors block">fixigoservices247@gmail.com</a>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-50 p-3 rounded-full shadow-inner">
                    <Clock className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">Working Hours</h3>
                    <p className="text-slate-600 mt-1">Monday - Saturday: 09:00 AM - 08:00 PM</p>
                    <p className="text-slate-600">Sunday: Emergency Only</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="bg-slate-200 rounded-2xl shadow-sm border border-slate-100 overflow-hidden h-[500px] relative hover:shadow-md transition-shadow">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3782.2613173278896!2d73.91411937501422!3d18.562253982539413!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c147b8b3a3bf%3A0x6f7fdcc8e4d6c77e!2sPhoenix%20Marketcity%20Pune!5e0!3m2!1sen!2sin!4v1709456789012!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Google Map"
              ></iframe>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Contact;
