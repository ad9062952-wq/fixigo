import React, { useEffect, useState } from 'react';
import { Fan, Cable, Power, Zap, Activity, AlertTriangle, Wrench, Droplet, Paintbrush, Wind } from 'lucide-react';
import { motion } from 'motion/react';
import Layout from '../components/Layout';
import { Link } from 'react-router-dom';
import Tilt from 'react-parallax-tilt';
import { getServices, Service } from '../lib/services';

const getIconForService = (name: string, category: string) => {
  const lowerName = name.toLowerCase();
  if (category === 'Plumber') return Droplet;
  if (category === 'Painter') return Paintbrush;
  if (category === 'AC Repair') return Wind;
  
  if (lowerName.includes('fan')) return Fan;
  if (lowerName.includes('wir')) return Cable;
  if (lowerName.includes('switch')) return Power;
  if (lowerName.includes('mcb') || lowerName.includes('fuse')) return Zap;
  if (lowerName.includes('meter')) return Activity;
  if (lowerName.includes('emerg')) return AlertTriangle;
  return Wrench;
};

const Services = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const data = await getServices();
        if (Array.isArray(data)) {
          setServices(data);
        } else {
          console.error('Expected array but got:', data);
          setServices([]);
        }
      } catch (error) {
        console.error('Error fetching services:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchServices();
  }, []);

  // Group services by category
  const groupedServices = services.reduce((acc, service) => {
    const category = service.category || 'Electrician';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(service);
    return acc;
  }, {} as Record<string, Service[]>);

  return (
    <Layout>
      <div className="bg-slate-50 py-12 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <motion.h1 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl font-bold text-slate-900 mb-4"
            >
              Our Services
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-lg text-slate-600 max-w-2xl mx-auto"
            >
              We offer a wide range of home services to keep your home safe and well-maintained.
            </motion.p>
          </div>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <div className="space-y-16">
              {Object.entries(groupedServices).map(([category, categoryServices]: [string, Service[]], catIndex) => (
                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: catIndex * 0.1 }}
                  key={category}
                >
                  <h2 className="text-2xl font-bold text-slate-900 mb-6 border-b border-slate-200 pb-2">{category} Services</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {categoryServices.map((service, index) => {
                      const Icon = getIconForService(service.name, service.category);
                      return (
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.9 }}
                          whileInView={{ opacity: 1, scale: 1 }}
                          viewport={{ once: true }}
                          transition={{ type: "spring", stiffness: 300, damping: 20, delay: index * 0.05 }}
                          key={service.id} 
                        >
                          <Tilt
                            tiltMaxAngleX={10}
                            tiltMaxAngleY={10}
                            perspective={1000}
                            transitionSpeed={1000}
                            scale={1.05}
                            gyroscope={true}
                            className="bg-white rounded-xl shadow-sm hover:shadow-xl overflow-hidden flex flex-col border border-slate-100 h-full transition-all duration-300"
                            style={{ transformStyle: "preserve-3d" }}
                          >
                            <div className="p-6 flex-grow" style={{ transform: "translateZ(30px)" }}>
                              <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center mb-4 shadow-inner">
                                <Icon className="h-6 w-6 text-blue-600" />
                              </div>
                              <h3 className="text-xl font-bold text-slate-900 mb-2">{service.name}</h3>
                              <p className="text-slate-600 mb-4">{service.description}</p>
                              <p className="text-green-600 font-semibold">{service.price_range}</p>
                            </div>
                            <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 relative z-10" style={{ transform: "translateZ(20px)" }}>
                              <Link
                                to="/book-service"
                                className="block w-full text-center bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition-all hover:scale-[1.02] font-medium shadow-md hover:shadow-lg relative z-20"
                              >
                                Book Now
                              </Link>
                            </div>
                          </Tilt>
                        </motion.div>
                      );
                    })}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default Services;
