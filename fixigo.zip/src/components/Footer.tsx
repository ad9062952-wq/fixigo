import React from 'react';
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, MessageCircle } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <img src="https://i.ibb.co/VY30HbV3/IMG-20260323-WA0008.jpg" alt="Fixigo Logo" className="h-10 w-10 rounded-full object-cover" referrerPolicy="no-referrer" />
              <h3 className="text-xl font-bold text-yellow-400">Fixigo Services</h3>
            </div>
            <p className="text-gray-400 mb-4">
              Fast & Reliable Home Services at Your Doorstep. We provide expert solutions for your home and business.
            </p>
            <div className="flex space-x-4">
              <a href="https://wa.me/917821835922" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-green-400 transition-colors"><MessageCircle className="h-5 w-5" /></a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors"><Facebook className="h-5 w-5" /></a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors"><Twitter className="h-5 w-5" /></a>
              <a href="https://www.instagram.com/fixigoservices.247?igsh=MXQzdG0wZ3hzY3N6ZQ==" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors"><Instagram className="h-5 w-5" /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/" className="text-gray-400 hover:text-yellow-400 transition-colors">Home</a></li>
              <li><a href="/services" className="text-gray-400 hover:text-yellow-400 transition-colors">Services</a></li>
              <li><a href="/about" className="text-gray-400 hover:text-yellow-400 transition-colors">About Us</a></li>
              <li><a href="/contact" className="text-gray-400 hover:text-yellow-400 transition-colors">Contact</a></li>
              <li><a href="/book-service" className="text-gray-400 hover:text-yellow-400 transition-colors">Book Now</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Contact Us</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-yellow-400 mt-1" />
                <span className="text-gray-400">Pune, Maharashtra, India</span>
              </div>
              <div className="flex items-center space-x-3">
                <MessageCircle className="h-5 w-5 text-green-400" />
                <a href="https://wa.me/917821835922" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-green-400 transition-colors">WhatsApp: +91 78218 35922</a>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-yellow-400" />
                <a href="tel:+917821835922" className="text-gray-400 hover:text-yellow-400 transition-colors">+91 78218 35922</a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-yellow-400" />
                <a href="mailto:fixigoservices247@gmail.com" className="text-gray-400 hover:text-yellow-400 transition-colors">fixigoservices247@gmail.com</a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Fixigo Services. All rights reserved.</p>
          <div className="mt-4 md:mt-0">
            <a href="/admin-login" className="hover:text-yellow-400 transition-colors">Admin Login</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
