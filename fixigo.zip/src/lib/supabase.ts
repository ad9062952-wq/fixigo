/// <reference types="vite/client" />
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://bzlbrekelzbzlufawxor.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_2qkF9QtAoI5BFw-UJBZiRw_tSKcB7VS';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
