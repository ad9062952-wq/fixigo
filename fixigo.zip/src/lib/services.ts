import { supabase } from './supabase';

export interface Service {
  id: number;
  name: string;
  description: string;
  price_range: string;
  category: string;
  is_active?: number;
  image_url?: string;
}

const DEFAULT_SERVICES: Service[] = [
  { id: 1, name: 'Fan Installation', description: 'Ceiling, exhaust, or wall fan installation and repair', price_range: '₹150 - ₹300', category: 'Electrician' },
  { id: 2, name: 'Wiring Repair', description: 'Fixing faulty wiring, short circuits, and new wiring', price_range: '₹200 - ₹500', category: 'Electrician' },
  { id: 3, name: 'Switchboard Repair', description: 'Repairing or replacing switches, sockets, and boards', price_range: '₹100 - ₹250', category: 'Electrician' },
  { id: 4, name: 'MCB / Fuse Repair', description: 'Fixing tripping MCBs, replacing blown fuses', price_range: '₹150 - ₹350', category: 'Electrician' },
  { id: 5, name: 'Meter Installation', description: 'Installing or shifting sub-meters', price_range: '₹300 - ₹600', category: 'Electrician' },
  { id: 6, name: 'Emergency Service', description: '24/7 emergency electrical repairs', price_range: '₹300 - ₹800', category: 'Electrician' },
  { id: 7, name: 'Pipe Leakage', description: 'Fixing leaking pipes and joints', price_range: '₹200 - ₹400', category: 'Plumber' },
  { id: 8, name: 'Tap Repair', description: 'Repairing or replacing faulty taps', price_range: '₹100 - ₹250', category: 'Plumber' },
  { id: 9, name: 'Interior Painting', description: 'Painting rooms and interior walls', price_range: '₹1000+', category: 'Painter' },
  { id: 10, name: 'AC Servicing', description: 'Regular AC cleaning and servicing', price_range: '₹400 - ₹800', category: 'AC Repair' },
];

export const getServices = async (): Promise<Service[]> => {
  try {
    const { data, error } = await supabase.from('services').select('*').order('id', { ascending: true });
    if (error) throw error;
    if (data && data.length > 0) return data as Service[];
  } catch (err) {
    console.error('Supabase fetch failed, falling back to localStorage:', err);
  }

  const stored = localStorage.getItem('app_services');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (e) {
      console.error('Failed to parse services from localStorage', e);
    }
  }
  return DEFAULT_SERVICES;
};

export const saveServices = async (services: Service[]) => {
  localStorage.setItem('app_services', JSON.stringify(services));
};

export const addService = async (service: Omit<Service, 'id'>) => {
  try {
    const { data, error } = await supabase.from('services').insert([service]).select();
    if (error) throw error;
    if (data && data.length > 0) return data[0] as Service;
  } catch (err) {
    console.error('Supabase insert failed, falling back to localStorage:', err);
  }

  const services = await getServices();
  const newId = services.length > 0 ? Math.max(...services.map(s => s.id)) + 1 : 1;
  const newService = { ...service, id: newId };
  await saveServices([...services, newService]);
  return newService;
};

export const deleteService = async (id: number) => {
  try {
    const { error } = await supabase.from('services').delete().eq('id', id);
    if (error) throw error;
  } catch (err) {
    console.error('Supabase delete failed, falling back to localStorage:', err);
  }

  const services = await getServices();
  await saveServices(services.filter(s => s.id !== id));
};

