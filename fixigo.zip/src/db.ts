import Database from 'better-sqlite3';
import bcrypt from 'bcrypt';

const db = new Database('app.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role TEXT NOT NULL,
    name TEXT NOT NULL,
    mobile TEXT UNIQUE NOT NULL,
    email TEXT,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    address TEXT,
    city TEXT,
    pincode TEXT,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS electricians (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    area TEXT,
    skills TEXT,
    experience TEXT,
    status TEXT DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    last_password_change DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    price_range TEXT,
    category TEXT DEFAULT 'Electrician',
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    electrician_id INTEGER,
    service_id INTEGER NOT NULL,
    address TEXT NOT NULL,
    problem_description TEXT,
    problem_photo TEXT,
    booking_date TEXT NOT NULL,
    booking_time TEXT NOT NULL,
    status TEXT DEFAULT 'Pending',
    total_amount INTEGER DEFAULT 0,
    electrician_earning INTEGER DEFAULT 0,
    platform_commission INTEGER DEFAULT 0,
    service_mode TEXT DEFAULT 'home',
    item_name TEXT,
    item_status TEXT,
    pickup_date TEXT,
    delivery_date TEXT,
    pickup_charge INTEGER DEFAULT 0,
    delivery_charge INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users (id),
    FOREIGN KEY (electrician_id) REFERENCES electricians (id),
    FOREIGN KEY (service_id) REFERENCES services (id)
  );

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id INTEGER NOT NULL,
    total_amount INTEGER NOT NULL,
    payment_method TEXT,
    payment_status TEXT DEFAULT 'Pending',
    who_collected_payment TEXT,
    commission_amount INTEGER DEFAULT 0,
    electrician_pay INTEGER DEFAULT 0,
    payment_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings (id)
  );

  CREATE TABLE IF NOT EXISTS admin_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    details TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users (id)
  );
`);

// Add new columns to bookings table if they don't exist
try { db.exec("ALTER TABLE services ADD COLUMN is_active INTEGER DEFAULT 1"); } catch (e) {}
try { db.exec("ALTER TABLE services ADD COLUMN category TEXT DEFAULT 'Electrician'"); } catch (e) {}
try { db.exec("ALTER TABLE bookings ADD COLUMN service_mode TEXT DEFAULT 'home'"); } catch (e) {}
try { db.exec("ALTER TABLE bookings ADD COLUMN item_name TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE bookings ADD COLUMN item_status TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE bookings ADD COLUMN pickup_date TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE bookings ADD COLUMN delivery_date TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE bookings ADD COLUMN pickup_charge INTEGER DEFAULT 0"); } catch (e) {}
try { db.exec("ALTER TABLE bookings ADD COLUMN delivery_charge INTEGER DEFAULT 0"); } catch (e) {}
try { db.exec("ALTER TABLE bookings ADD COLUMN electrician_earning INTEGER DEFAULT 0"); } catch (e) {}
try { db.exec("ALTER TABLE bookings ADD COLUMN platform_commission INTEGER DEFAULT 0"); } catch (e) {}

// Add new columns to payments table if they don't exist
try { db.exec("ALTER TABLE payments ADD COLUMN who_collected_payment TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE payments ADD COLUMN commission_amount INTEGER DEFAULT 0"); } catch (e) {}
try { db.exec("ALTER TABLE payments ADD COLUMN electrician_pay INTEGER DEFAULT 0"); } catch (e) {}

// Add new columns to electricians table for live tracking
try { db.exec("ALTER TABLE electricians ADD COLUMN latitude REAL"); } catch (e) {}
try { db.exec("ALTER TABLE electricians ADD COLUMN longitude REAL"); } catch (e) {}
try { db.exec("ALTER TABLE electricians ADD COLUMN last_updated_time DATETIME"); } catch (e) {}
try { db.exec("ALTER TABLE electricians ADD COLUMN category TEXT DEFAULT 'Electrician'"); } catch (e) {}

// Add location columns to bookings
try { db.exec("ALTER TABLE bookings ADD COLUMN latitude REAL"); } catch (e) {}
try { db.exec("ALTER TABLE bookings ADD COLUMN longitude REAL"); } catch (e) {}

// Create admin_logs if it doesn't exist (just in case the CREATE TABLE IF NOT EXISTS block failed earlier)
try {
  db.exec(`
    CREATE TABLE IF NOT EXISTS admin_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      admin_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      details TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (admin_id) REFERENCES users (id)
    );
  `);
} catch (e) {}

// Seed Admin
const adminCheck = db.prepare("SELECT * FROM users WHERE role = 'admin'").get();
const hashedPassword = bcrypt.hashSync('mayuri8010', 10);
if (!adminCheck) {
  try {
    const info = db.prepare("INSERT INTO users (name, mobile, password_hash, role) VALUES (?, ?, ?, ?)").run('Admin', '8010733617', hashedPassword, 'admin');
    db.prepare("INSERT INTO admins (user_id) VALUES (?)").run(info.lastInsertRowid);
  } catch (e) {
    console.error("Failed to seed admin:", e);
  }
} else {
  try {
    db.prepare("UPDATE users SET mobile = ?, password_hash = ? WHERE role = 'admin'").run('8010733617', hashedPassword);
  } catch (e) {
    console.error("Failed to update admin:", e);
  }
}

// Seed Services
const serviceCheck = db.prepare("SELECT count(*) as count FROM services").get() as any;
if (serviceCheck.count === 0) {
  const insertService = db.prepare("INSERT INTO services (name, description, price_range, category) VALUES (?, ?, ?, ?)");
  insertService.run('Fan Installation', 'Ceiling, exhaust, and wall fans', '₹250 - ₹500', 'Electrician');
  insertService.run('Wiring Repair', 'Fault detection and rewiring', '₹300 - ₹2000', 'Electrician');
  insertService.run('Switchboard Repair', 'Fixing switches and sockets', '₹150 - ₹800', 'Electrician');
  insertService.run('MCB / Fuse Repair', 'Tripping MCBs and fuses', '₹350 - ₹1500', 'Electrician');
  insertService.run('Meter Installation', 'Sub-meter and main board', '₹800 - ₹3000', 'Electrician');
  insertService.run('Emergency Service', '24/7 support for power failures', 'On Inspection', 'Electrician');
  
  // Plumber services
  insertService.run('Tap Repair', 'Fixing leaking taps and faucets', '₹150 - ₹400', 'Plumber');
  insertService.run('Pipe Leakage', 'Detecting and fixing pipe leaks', '₹300 - ₹1500', 'Plumber');
  insertService.run('Water Tank Cleaning', 'Deep cleaning of water tanks', '₹500 - ₹2000', 'Plumber');
  
  // Painter services
  insertService.run('Interior Painting', 'Wall painting for rooms', '₹2000 - ₹10000', 'Painter');
  insertService.run('Exterior Painting', 'Weatherproof exterior painting', '₹5000 - ₹25000', 'Painter');

  // AC Repair services
  insertService.run('AC Servicing', 'Deep cleaning and maintenance', '₹499 - ₹999', 'AC Repair');
  insertService.run('AC Gas Refill', 'Cooling issue fix with gas refill', '₹1500 - ₹2500', 'AC Repair');
  insertService.run('AC Installation', 'Split and Window AC installation', '₹1000 - ₹2000', 'AC Repair');
}

// Seed dummy users and bookings if none exist
const bookingCheck = db.prepare("SELECT count(*) as count FROM bookings").get() as any;
if (bookingCheck.count === 0) {
  try {
    const userHash = bcrypt.hashSync('password123', 10);
    const user1 = db.prepare("INSERT INTO users (name, mobile, password_hash, role) VALUES (?, ?, ?, ?)").run('John Doe', '9876543210', userHash, 'customer');
    const user2 = db.prepare("INSERT INTO users (name, mobile, password_hash, role) VALUES (?, ?, ?, ?)").run('Jane Smith', '9876543211', userHash, 'customer');
    const elec1 = db.prepare("INSERT INTO users (name, mobile, password_hash, role) VALUES (?, ?, ?, ?)").run('Mike Electrician', '9876543212', userHash, 'electrician');
    
    db.prepare("INSERT INTO electricians (user_id, experience, status) VALUES (?, ?, ?)").run(elec1.lastInsertRowid, '5 years', 'approved');

    db.prepare(`
      INSERT INTO bookings (customer_id, service_id, address, problem_description, booking_date, booking_time, status, service_mode, item_name, item_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(user1.lastInsertRowid, 1, '123 Main St', 'Fan making noise', '2023-10-25', '10:00', 'Pending', 'home', null, null);

    db.prepare(`
      INSERT INTO bookings (customer_id, service_id, address, problem_description, booking_date, booking_time, status, service_mode, item_name, item_status, pickup_date, delivery_date)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(user2.lastInsertRowid, 2, '456 Elm St', 'Wire burnt', '2023-10-26', '14:00', 'Assigned', 'pickup', 'Mixer Grinder', 'Under Repair', '2023-10-26', '2023-10-28');
    
    // Seed some admin logs
    db.prepare("INSERT INTO admin_logs (admin_id, action, details) VALUES (?, ?, ?)").run(1, 'SYSTEM_INIT', 'System initialized with dummy data');
  } catch (e) {
    console.error("Failed to seed dummy data:", e);
  }
}

export default db;
